<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

## Project 3

### Learning Goal

  1. Forms

** The Breakfast Restaurant **

A website for a restaurant that only serves breakfast.

You’ll need to have three separate HTML files. The images should be located in a folder called “img”.

The idea is to practice linking between separate files, as well as accessing files located in different folders (images in this case.)
