<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# Project 5

**Become a Programmer. See the World.** 

A website that describes the benefits of being a programmer. This project will gain you experience in HTML tables.

The images should be resized in the HTML to have a width of 600 and a height of 300.