<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# Command Line Project #2

## Learning Goal

How to use the desktop (Finder or Windows Explorer)

Note: for this project, you cannot use the “cd” command. Do everything from the desktop.

1. On your desktop, create a folder called “drinks”.

2. Inside of drinks, create three folders: Smoothies, FrozenDrinks and IcedSpecialtyDrinks.

3. Rename the “Smoothies” folder to “PowerSmoothies”.

4. Inside of PowerSmoothies, create three files: 
    1. PeachAndBlueberry.txt, 
    2. GreenPassion.txt, and 
    3. Superfruit.txt.

5. Inside of FrozenDrinks, create three files: 
    1. WatermelonStrawberryLemonade.html, 
    2. Caramel.html, and 
    3. Mocha.html.

6. Inside of IcedSpecialityDrinks, create four files: 
    1. CaramelLatte.css, 
    2. ChaiTeaLatte.css, 
    3. CaffeMocha.css, and 
    4. CaffeLatte.css.

7. Delete CaffeLatte.css. 

That’s enough caffeine for today!