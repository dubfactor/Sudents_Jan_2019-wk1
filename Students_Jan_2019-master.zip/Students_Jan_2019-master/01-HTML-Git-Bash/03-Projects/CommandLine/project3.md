<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# Command Line - Project 3

### Please answer the following questions.

1. What command would you use to clear the screen?

2. What is the shortcut command to open a new tab in your terminal?

3. What key would you use to scroll through previous commands you’ve typed before?

4. You have a three txt files and an empty folder on your desktop. Write a single line command that will move all three txt files into the folder.

5. You want to inspect the differences between two txt files myfile1.txt and myfile2.txt. Write a command that would display the differences in content between these two files.

6. Write a command that would delete this folder and all of the contents inside.

7. What is the command to list all files, including hidden files?  Write a command that displays all .css files in a folder.

8. What is the command to find a file by name on your disk (or some other storage medium)?

9. What is the command to find a file by content
    
    1. in your folder 
    2. on the disk?  
  
    That is, how do you search for a word or phrase in the file contents?

10. Use a bash command to create a file named YourName.txt with no content in it.  Look at it's permissions.
  
    1. Now change its permissions so everyone can read it and execute it.  
    2. Now change its permissions so only you can read it.

Done!