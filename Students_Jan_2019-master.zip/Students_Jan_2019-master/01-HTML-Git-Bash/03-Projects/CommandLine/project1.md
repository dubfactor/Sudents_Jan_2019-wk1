<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# Project #1

## Learning Goal

How to manage your files on ** command line **

1. On your desktop, create a folder named “soups”.
2. Go inside of your soups folder. Create a file called “ChickenNoodle.html” and “BakedPotato.css”
3. While you’re inside of the soups folder, create another folder called “js”.
4. Go inside of the js folder. Where are we? Display the current path that we are on.
5. Now go back to the soups folder.
6. Create a file called “CreamyTomato.js” and put it in the js folder while still in the soups folder.
7. Create a file called “readme.txt.” in the soups folder.
8. On second thought, maybe we don’t need a readme file right. Delete “readme.txt”.
9. Go into the js folder.
10. You decide you’re not in the mood for creamy tomato. Rename “CreamyTomato.js” to “BroccoliCheddar.js”.

**You’re done!**

