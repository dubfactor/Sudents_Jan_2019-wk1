<center>

### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 
Mar 2018 - Sept 2018

</center>

# Git Project 1

1. Create a new empty folder. Initialize an empty git repository in this folder. 
2. Inside the folder, create an html file called “index.html”, and put in boilerplate code (HTML Doctype).
3. Check the git status. What do you see?
4. Add the html file to the repo.
5. Commit with the message “Added HTML file.”
6. Create a file called “style.css”. Check the status.
7. Add the css file to the repo.
8. Commit with the message “Added CSS file.”
9. Create two files and call them “part1.js” and “part2.js”. Add both files to the repo at the same time. (Think about what command you would type to make this happen.)
10. Commit your changes and give it a message of your own liking.
11. Check out a list of all your changes using “git log”.

