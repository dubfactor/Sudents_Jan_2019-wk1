<center>

### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 
Mar 2018 - Sept 2018

</center>

# Git Project 3

1. Create a branch called "try"
2. Checkout the try branch.
3. Make some changes and commit.
4. Checkout master branch.
5. Make some changes and commit.
6. Merge the changes from the try branch.
7. Review the changes with git diff.
8. Reset the changes made to try.
9. Delete try branch.
10. Push to remote.