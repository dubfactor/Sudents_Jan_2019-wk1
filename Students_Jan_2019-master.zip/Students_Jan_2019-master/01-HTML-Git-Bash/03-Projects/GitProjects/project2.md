<center>

### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 
Mar 2018 - Sept 2018

</center>

# Git Project 2

  1. Go to github.com within ACCSoftwareBootcamp and create a new --private repository--.  Name it with your firstname only.  Copy the url somewhere on your local machine.
  2. Open command line
  3. Change the current working directory to your code repository folder on your local file system.
  4. Initialize a new repo here.
  5. Add all the files to the index.
  6. Run "git status" to see what happened.
  7. Commit all files.  Give them a self explanatory commit message.
  8. Run "git status" again.
  9. Setup a new remote pointer, pointing to your newly created private repo (paste the url from Step 1 above).
  10. Push your initial commit to the remote.

From now on, any project that you are working on should be saved onto Github. Start gaining practice and familiarity now!
  