<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# Instructions

Your task is to re-create from scratch the websites that you see from the screenshots/videos. Each project is it’s own individual website which may have one or more pages. Detailed instructions for each project are listed below. Good luck!
