<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>

# PROJECT 2: The Steve Jobs Fansite

## Learning Goal

  1. How to link files and sites

A website devoted to the founder and former CEO of Apple Inc., Steve Jobs. This project will help you gain experience in writing links in HTML.

The text on your page should be connected to the following links:

- [Steve Wozniak](https://en.wikipedia.org/wiki/Steve_Wozniak)

- [Apple II](https://en.wikipedia.org/wiki/Apple_II)

- [Pixar](https://en.wikipedia.org/wiki/Pixar)

- [Steve was a fantastic salesman](https://en.wikipedia.org/wiki/Reality_distortion_field)

- [Remembering Steve](http://www.apple.com/stevejobs/)

- [The Steve Jobs Biography](https://www.amazon.com/Steve-Jobs-Walter-Isaacson/dp/1451648537)

- [The Steve Jobs Movie](http://www.imdb.com/title/tt2080374/)


There are three Youtube videos at the bottom the page. Here are the links:

- https://www.youtube.com/embed/UvEiSa6_EPA
- https://www.youtube.com/embed/upzKj-1HaKw
- https://www.youtube.com/embed/5Z1gfgM7kzo
