<center>
 
### AUSTIN COMMUNITY COLLEGE 
#### Web Software Bootcamp 2018
###### January 2019 - August 2019

</center>


# Links to Lecture Slides and Other Useful Resources

Note: Sometimes you may have to request permission to view and comment on the
slides.  Please request it, via your browser when you click on these links
below and we'll provide you with the permission as quickly as we can.

## ACC Software Bootcamp - Starting Up
1. #### [Introduction & Instructions & Useful Stuff - Google Slides](https://docs.google.com/presentation/d/1_03vy14hWa-h5FeuAgnPPNenjwLaUehl25sCNxIU-qU/edit?usp=sharing)

## ACC Software Bootcamp - Starting Up - RECORDINGS
1. #### [Class Discussions - Zoom Recordings](https://drive.google.com/drive/folders/1mll2XQ3DRWVKU-OUM3vy4h3pbHviP99M?usp=sharing)

## Hacking Google
1. #### [Hacking Google - Google Slides](https://docs.google.com/presentation/d/1MmQoZZrkkwWUbCMfOkYAN9GbhL24uSPRi1nrrlRs2Ss/edit?usp=sharing)

## Terminal, Command Line (Bash) and Git
1. #### [How to use your command line - Google Slides](https://docs.google.com/presentation/d/1aHMf2KJHAmOfBUqCdfKoi4jcn_JtNyvdvcdlxwdqby8/edit?usp=sharing)

